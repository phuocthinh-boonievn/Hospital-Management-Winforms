﻿using BusinessObjects;
using Repositories;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HosplitalManagement
{
    public partial class frmMain : Form
    {
        private readonly Account sessionAcc;
        private BindingSource source;
        private int tmpID;
        PatientRepository patientRepository;
        AccountRepository accountRepository;
        DoctorRepository doctorRepository;
        AppointmentRepository appointmentRepository;
        BillRepository billRepository;
        MedicineRepository medicineRepository;
        PrescriptionRepository prescriptionRepository;
        public frmMain(Account acc)
        {
            InitializeComponent();
            sessionAcc = acc;
            patientRepository = new PatientRepository();
            accountRepository = new AccountRepository();
            doctorRepository = new DoctorRepository();
            appointmentRepository = new AppointmentRepository();
            billRepository = new BillRepository();
            prescriptionRepository = new PrescriptionRepository();
            medicineRepository = new MedicineRepository();
            DisplayForUserLevel();
        }
        //Yes/No Confirmation msgBox
        private DialogResult confirmationMssBox(string message, string title)
        {
            MessageBoxButtons buttons = MessageBoxButtons.YesNo;
            DialogResult result = MessageBox.Show(message, title, buttons);
            return result;
        }
        private void frmMain_Load(object sender, EventArgs e)
        {
            LoadAccountData();
            dgvDisplayFormat(dgvDisplayAccounts, "Doctors", "Patients");
            rbDoctorPF.Checked = true;
            LoadAppointmentData();
            LoadDocNamesCB();
            LoadDgvBill();
            //LoadProfileData();
            //dgvDisplayFormat(dgvDisplayProfiles, "Account", "Appointments");
            dtpAppointmentDate.MinDate = DateTime.Today.AddDays(1);
            //dtpAppointmentDate.MaxDate = DateTime.Today.AddDays(7).AddHours(12);
        }
        private void DisplayForUserLevel()
        {
            btnDeleteAppointment.Visible = false;
            if (sessionAcc.Role == 0)
            {

            }
            else if (sessionAcc.Role == 1)
            {
                lbSearchAcc.Visible = false; txtSearchAccount.Visible = false;
                lbDisplayPFMode.Visible = false;rbDoctorPF.Visible = false;rbPatientPF.Visible = false;
                btnCreateAppointment.Visible = false;
            }
            else if (sessionAcc.Role == 2)
            {
                lbSearchAcc.Visible = false; txtSearchAccount.Visible = false;
                lbDisplayPFMode.Visible = false; rbDoctorPF.Visible = false; rbPatientPF.Visible = false;
                btnEditAppointment.Visible = false;
            }
            //Limit input to letters only
            private void tbLetterOnly_KeyPress(object sender, KeyPressEventArgs e)
            {
                e.Handled = !char.IsLetter(e.KeyChar) && !char.IsControl(e.KeyChar) && !char.IsWhiteSpace(e.KeyChar);
            }
            //Limit input to number only
            private void tbNumberOnly_KeyPress(object sender, KeyPressEventArgs e)
            {
                e.Handled = !char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar);
            }
        }
        //---------------------------------------------------------------
        //----------------------AccountManangement-----------------------
        //---------------------------------------------------------------
        private void LoadAccountWithFormat()
        {
            LoadAccountData();
            dgvDisplayFormat(dgvDisplayAccounts, "Doctors", "Patients");
        }

        //Get dgv ID on header click
        private void dgvDisplayAccounts_RowHeaderMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            try
            {
                tmpID = Convert.ToInt32(dgvDisplayAccounts.Rows[e.RowIndex].Cells[0].Value.ToString());
            }
            catch
            {
                tmpID = 0;
            }
        }
        private void LoadAccountData()
        {
            var accs = accountRepository.GetAll();
            if (sessionAcc.Role == 0) { accs = accountRepository.GetAll(); }
            else if (sessionAcc.Role == 1) { accs = accountRepository.GetAll().Where(a => a.AccountId == sessionAcc.AccountId); }
            else if (sessionAcc.Role == 2) { accs = accountRepository.GetAll().Where(a => a.AccountId == sessionAcc.AccountId); }
            source = new BindingSource();
            try
            {
                source.DataSource = accs;
                dgvDisplayAccounts.DataSource = null;
                dgvDisplayAccounts.DataSource = accs;
            }
            catch (Exception ex) { }
        }
        private void dgvDisplayFormat(DataGridView dgv, string str1, string str2)
        {
            dgv.Columns[str1].Visible = false;
            dgv.Columns[str2].Visible = false;
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            /*if(txtSearchAccount.Text == string.Empty)
            {
                LoadAccountData();
            }
            else
            {
                var accs = accountRepository.Search(txtSearchAccount.Text);
                dgvDisplayAccounts.DataSource = null;
                dgvDisplayAccounts.DataSource = accs;
            }*/
            var accs = accountRepository.Search(txtSearchAccount.Text);
            dgvDisplayAccounts.DataSource = null;
            dgvDisplayAccounts.DataSource = accs;
        }
        private void btnCreate_Click(object sender, EventArgs e)
        {
            Account account = null;
            frmAddDoctorAccount addAccount = new frmAddDoctorAccount(account, 0);
            addAccount.ShowDialog();
            tmpID = 0;
            LoadAccountWithFormat();
        }
        private void btnUpdateDocAccount_Click(object sender, EventArgs e)
        {
            if (tmpID == 0)
            {
                MessageBox.Show("Please select an account row header to update");
            }
            else
            {
                Account account = accountRepository.GetByID(tmpID);
                frmAddDoctorAccount doctorAccount = new frmAddDoctorAccount(account, 1);
                doctorAccount.ShowDialog();
                LoadAccountWithFormat();
                tmpID = 0;
            }
        }

        private void btnDeleteDocAccount_Click(object sender, EventArgs e)
        {
            if (tmpID == 0)
            {
                MessageBox.Show("Please select an account row header to delete");
            }
            else
            {
                var result = confirmationMssBox("Delete Account", "Confirmation");
                if (result == DialogResult.Yes)
                {
                    try
                    {
                        accountRepository.Delete(tmpID);
                        MessageBox.Show("Account deleted");
                        tmpID = 0;
                        LoadAccountWithFormat();
                    }
                    catch { MessageBox.Show("Failed to delete the account"); }
                }
                else { return; }
            }
        }
        //---------------------------------------------------------------
        //----------------------ProfileManangement-----------------------
        //---------------------------------------------------------------
        private void LoadProfileWithFormat()
        {
            LoadProfileData();
            dgvDisplayFormat(dgvDisplayProfiles, "Account", "Appointments");
        }
        private void LoadProfileData()
        {
            if (rbDoctorPF.Checked)
            {
                var pros = doctorRepository.GetAll();
                source = new BindingSource();
                try
                {
                    source.DataSource = pros;
                    dgvDisplayProfiles.DataSource = null;
                    dgvDisplayProfiles.DataSource = pros;
                }
                catch (Exception ex) { }
            }
            else if (rbPatientPF.Checked)
            {
                var pros = patientRepository.GetAll();
                source = new BindingSource();
                try
                {
                    source.DataSource = pros;
                    dgvDisplayProfiles.DataSource = null;
                    dgvDisplayProfiles.DataSource = pros;
                }
                catch (Exception ex) { }
            }
        }

        private void rbDoctorPF_CheckedChanged(object sender, EventArgs e)
        {
            if (rbDoctorPF.Checked == true)
            {
                LoadProfileWithFormat();
            }
        }

        private void rbPatientPF_CheckedChanged(object sender, EventArgs e)
        {
            if (rbPatientPF.Checked == true)
            {
                LoadProfileWithFormat();
            }
        }

        private void txtSearchPF_TextChanged(object sender, EventArgs e)
        {
            if (sessionAcc.Role == 0)
            {
                if (rbPatientPF.Checked == true)
                {
                    var patients = patientRepository.SearchByName(txtSearchPF.Text);
                    source.DataSource = patients;
                    dgvDisplayProfiles.DataSource = null;
                    dgvDisplayProfiles.DataSource = patients;
                }
                else if (rbDoctorPF.Checked == true)
                {
                    var doctors = doctorRepository.SearchByName(txtSearchPF.Text);
                    source.DataSource = doctors;
                    dgvDisplayProfiles.DataSource = null;
                    dgvDisplayProfiles.DataSource = doctors;
                }
            }
            else if (sessionAcc.Role == 1)
            {
                var doctors = doctorRepository.SearchByName(txtSearchPF.Text).Where(a => a.AccountId == sessionAcc.AccountId);
                source.DataSource = doctors;
                dgvDisplayProfiles.DataSource = null;
                dgvDisplayProfiles.DataSource = doctors;
            }
            else if (sessionAcc.Role == 2)
            {
                var patients = patientRepository.SearchByName(txtSearchPF.Text).Where(a => a.AccountId == sessionAcc.AccountId);
                source.DataSource = patients;
                dgvDisplayProfiles.DataSource = null;
                dgvDisplayProfiles.DataSource = source;
            }
        }

        private void btnCreatePF_Click(object sender, EventArgs e)
        {
            if (rbDoctorPF.Checked = true)
            {
                Doctor doctor = null;
                frmAddDocPF docPF = new frmAddDocPF(doctor, 0);
                docPF.ShowDialog();
                tmpID = 0;
                LoadProfileWithFormat();
            }
            else if (rbPatientPF.Checked == true)
            {

            }
        }

        private void dgvDisplayProfiles_RowHeaderMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            try
            {
                tmpID = Convert.ToInt32(dgvDisplayProfiles.Rows[e.RowIndex].Cells[0].Value.ToString());
            }
            catch
            {
                tmpID = 0;
            }
        }

        private void btnUpdatePF_Click(object sender, EventArgs e)
        {
            if (rbDoctorPF.Checked == true)
            {
                if (tmpID == 0)
                {
                    MessageBox.Show("Please select a profile row header to update");
                }
                else
                {
                    Doctor doctor = doctorRepository.GetByID(tmpID);
                    frmAddDocPF frmPF = new frmAddDocPF(doctor, 1);
                    frmPF.ShowDialog();
                    tmpID = 0;
                    LoadProfileWithFormat();
                }

            }
            else if (rbPatientPF.Checked == true) { }
        }

        private void btnDeletePF_Click(object sender, EventArgs e)
        {
            if (rbDoctorPF.Checked == true)
            {
                if (tmpID == 0)
                {
                    MessageBox.Show("Please select a profile row header to delete");
                }
                else
                {
                    var result = confirmationMssBox("Delete Profile", "Confirmation");
                    if (result == DialogResult.Yes)
                    {
                        try
                        {
                            doctorRepository.Delete(tmpID);
                            MessageBox.Show("Profile deleted");
                            tmpID = 0;
                            LoadProfileWithFormat();
                        }
                        catch { MessageBox.Show("Failed to delete the profile"); }
                    }
                    else { return; }
                }
            }
            else if (rbPatientPF.Checked == true) { }
        }

        private void tcMain_SelectedIndexChanged(object sender, EventArgs e)
        {
            tmpID = 0;
        }

        //---------------------------------------------------------------
        //----------------------AppointmentManangement-------------------
        //---------------------------------------------------------------

        private void LoadAppointmentData()
        {           
            if (sessionAcc.Role == 0) 
            {
                var appointments = appointmentRepository.GetAll();
                source = new BindingSource();
                try
                {
                    source.DataSource = appointments;
                    dgvDisplayAppointments.DataSource = null;
                    dgvDisplayAppointments.DataSource = source;
                    dgvDisplayAppointments.Columns["Patient"].Visible = false;
                    dgvDisplayAppointments.Columns["Doctor"].Visible = false;
                    dgvDisplayAppointments.Columns["HospitalBill"].Visible = false;
                }
                catch { }
            }
            else if (sessionAcc.Role == 1) 
            {
                var appointments = appointmentRepository.GetAll();
                source = new BindingSource();
                try
                {
                    source.DataSource = appointments;
                    dgvDisplayAppointments.DataSource = null;
                    dgvDisplayAppointments.DataSource = source;
                    dgvDisplayAppointments.Columns["Patient"].Visible = false;
                    dgvDisplayAppointments.Columns["Doctor"].Visible = false;
                    dgvDisplayAppointments.Columns["HospitalBill"].Visible = false;
                }
                catch { }
            }
            else if (sessionAcc.Role == 2) 
            {
                var appointments = appointmentRepository.GetAll();
                source = new BindingSource();
                try
                {
                    source.DataSource = appointments;
                    dgvDisplayAppointments.DataSource = null;
                    dgvDisplayAppointments.DataSource = source;
                    dgvDisplayAppointments.Columns["Patient"].Visible = false;
                    dgvDisplayAppointments.Columns["Doctor"].Visible = false;
                    dgvDisplayAppointments.Columns["HospitalBill"].Visible = false;
                }
                catch { }
            }
        }
        private void LoadDocNamesCB()
        {
            var doctors = doctorRepository.GetAll();
            foreach (var doc in doctors)
            {
                if (!cbSelectDoctor.Items.Contains(doc.DoctorId))
                {
                    cbSelectDoctor.Items.Add(doc.DoctorName);
                }
            }
        }
        private Appointment GetAppointment(string status)
        {
            Appointment appointment = null;
            if (cbSelectDoctor.Text == string.Empty)
            {
                return appointment;
            }
            else
            {
                try
                {
                    var doctors = doctorRepository.GetAll();
                    Doctor doctor = doctors.SingleOrDefault(p => p.DoctorName == cbSelectDoctor.Text);
                    appointment = new Appointment
                    {
                        Status = status,
                        AppointedDate = dtpAppointmentDate.Value,
                        DoctorId = doctor.DoctorId,
                        PatientId = sessionAcc.AccountId
                    };
                    //MessageBox.Show($"DocID:{doctor.DoctorId}");
                }
                catch (Exception ex) { MessageBox.Show("Nope"); }
            }
            return appointment;
        }
        private void btnCreateAppointment_Click(object sender, EventArgs e)
        {
            if (cbSelectDoctor.Text == string.Empty)
            {
                MessageBox.Show("Doctor field must not be empty");
            }
            else
            {
                Appointment appointment = GetAppointment("Not Yet");
                bool flag = true;
                var appointments = appointmentRepository.GetAll().Where(p => p.DoctorId == appointment.DoctorId);
                if (appointments.Any())
                {
                    foreach (var app in appointments)
                    {
                        if (appointment.AppointedDate >= app.AppointedDate && appointment.AppointedDate < app.AppointedDate.AddHours(2))
                        {
                            MessageBox.Show("Conflicted schedule");
                            flag = false;
                            break;
                        }
                    }
                }
                if (flag)
                {
                    try
                    {
                        appointmentRepository.Insert(appointment);
                        MessageBox.Show("done");
                        LoadAppointmentData();
                    }
                    catch { MessageBox.Show("Uh oh"); }
                }
            }            
        }

        private void btnEditAppointment_Click(object sender, EventArgs e)
        {
            if(cbStatus.Text == string.Empty)
            {
                MessageBox.Show("Status field must not be empty");
            }
            else
            {
                Appointment appointment = appointmentRepository.GetByID(tmpID);
                try
                {
                    appointment.Status = cbStatus.Text;
                    appointmentRepository.Update(appointment);
                    MessageBox.Show("done");
                    appointment = appointmentRepository.GetByID(tmpID);
                    bool tmpF = billRepository.CheckExist(tmpID);
                    if (!tmpF && appointment.Status == "Finished")
                    {
                        BillDetail detail = new BillDetail(appointment);
                        detail.ShowDialog();
                    }
                    tmpID = 0;
                    LoadAppointmentData();
                }
                catch { MessageBox.Show("Update failed"); }
            }          
        }

        private void btnDeleteAppointment_Click(object sender, EventArgs e)
        {
            MessageBoxButtons buttons = MessageBoxButtons.YesNo;
            var result = confirmationMssBox("Delete?", "Confirm");
            if (result == DialogResult.Yes)
            {
                appointmentRepository.Delete(tmpID);
                tmpID = 0;
                LoadAppointmentData();
            }
            else { }
        }

        private void dgvDisplayAppointments_RowHeaderMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            try
            {
                tmpID = Convert.ToInt32(dgvDisplayAppointments.Rows[e.RowIndex].Cells[0].Value.ToString());
            }
            catch
            {
                tmpID = 0;
            }
        }
        //---------------------------------------------------------------
        //----------------------BillManagement---------------------------
        //---------------------------------------------------------------
        private void LoadDgvBill()
        {
            var bills = billRepository.GetAll();
            try
            {
                source = new BindingSource();
                source.DataSource = bills;
                dgvDisplayBill.DataSource = null;
                dgvDisplayBill.DataSource = source;
            }
            catch { }
        }

        private void dgvDisplayBill_RowHeaderMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            try
            {
                tmpID = Convert.ToInt32(dgvDisplayBill.Rows[e.RowIndex].Cells[0].Value.ToString());
                if (tmpID != 0)
                {
                    var billDetail = prescriptionRepository.GetAll().Where(p => p.BillId == tmpID);
                    source = new BindingSource();
                    try
                    {
                        source.DataSource = billDetail;
                        dgvDisplayBillDetail.DataSource = source;
                    }
                    catch { }
                }
                else { dgvDisplayBillDetail.DataSource = null; }
            }
            catch
            {
                tmpID = 0;
                //dgvDisplayBillDetail = null;
            }
        }
    }
}
