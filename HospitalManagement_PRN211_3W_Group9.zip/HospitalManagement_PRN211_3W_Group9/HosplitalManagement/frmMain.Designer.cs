﻿namespace HosplitalManagement
{
    partial class frmMain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            tcMain = new System.Windows.Forms.TabControl();
            tpAccount = new System.Windows.Forms.TabPage();
            txtSearchAccount = new System.Windows.Forms.TextBox();
            lbSearchAcc = new System.Windows.Forms.Label();
            btnDeleteDocAccount = new System.Windows.Forms.Button();
            btnUpdateDocAccount = new System.Windows.Forms.Button();
            btnCreateDocAccount = new System.Windows.Forms.Button();
            dgvDisplayAccounts = new System.Windows.Forms.DataGridView();
            tpProfile = new System.Windows.Forms.TabPage();
            lbDisplayPFMode = new System.Windows.Forms.Label();
            rbPatientPF = new System.Windows.Forms.RadioButton();
            rbDoctorPF = new System.Windows.Forms.RadioButton();
            btnDeletePF = new System.Windows.Forms.Button();
            btnUpdatePF = new System.Windows.Forms.Button();
            btnCreatePF = new System.Windows.Forms.Button();
            txtSearchPF = new System.Windows.Forms.TextBox();
            lbSearchPF = new System.Windows.Forms.Label();
            dgvDisplayProfiles = new System.Windows.Forms.DataGridView();
            tpAppointment = new System.Windows.Forms.TabPage();
            dtpAppointmentDate = new System.Windows.Forms.DateTimePicker();
            btnDeleteAppointment = new System.Windows.Forms.Button();
            btnEditAppointment = new System.Windows.Forms.Button();
            btnCreateAppointment = new System.Windows.Forms.Button();
            txtSearchAppointmentByID = new System.Windows.Forms.TextBox();
            cbStatus = new System.Windows.Forms.ComboBox();
            cbSelectDoctor = new System.Windows.Forms.ComboBox();
            Filter = new System.Windows.Forms.Label();
            label5 = new System.Windows.Forms.Label();
            label4 = new System.Windows.Forms.Label();
            label3 = new System.Windows.Forms.Label();
            label2 = new System.Windows.Forms.Label();
            dgvDisplayAppointments = new System.Windows.Forms.DataGridView();
            tpHospitalBill = new System.Windows.Forms.TabPage();
            dgvDisplayBillDetail = new System.Windows.Forms.DataGridView();
            dgvDisplayBill = new System.Windows.Forms.DataGridView();
            tpMedicine = new System.Windows.Forms.TabPage();
            tcMain.SuspendLayout();
            tpAccount.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dgvDisplayAccounts).BeginInit();
            tpProfile.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dgvDisplayProfiles).BeginInit();
            tpAppointment.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dgvDisplayAppointments).BeginInit();
            tpHospitalBill.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dgvDisplayBillDetail).BeginInit();
            ((System.ComponentModel.ISupportInitialize)dgvDisplayBill).BeginInit();
            SuspendLayout();
            // 
            // tcMain
            // 
            tcMain.Controls.Add(tpAccount);
            tcMain.Controls.Add(tpProfile);
            tcMain.Controls.Add(tpAppointment);
            tcMain.Controls.Add(tpHospitalBill);
            tcMain.Controls.Add(tpMedicine);
            tcMain.Location = new System.Drawing.Point(2, 1);
            tcMain.Name = "tcMain";
            tcMain.SelectedIndex = 0;
            tcMain.Size = new System.Drawing.Size(878, 481);
            tcMain.TabIndex = 0;
            tcMain.SelectedIndexChanged += tcMain_SelectedIndexChanged;
            // 
            // tpAccount
            // 
            tpAccount.Controls.Add(txtSearchAccount);
            tpAccount.Controls.Add(lbSearchAcc);
            tpAccount.Controls.Add(btnDeleteDocAccount);
            tpAccount.Controls.Add(btnUpdateDocAccount);
            tpAccount.Controls.Add(btnCreateDocAccount);
            tpAccount.Controls.Add(dgvDisplayAccounts);
            tpAccount.Location = new System.Drawing.Point(4, 34);
            tpAccount.Name = "tpAccount";
            tpAccount.Padding = new System.Windows.Forms.Padding(3);
            tpAccount.Size = new System.Drawing.Size(870, 443);
            tpAccount.TabIndex = 0;
            tpAccount.Text = "Accounts";
            tpAccount.UseVisualStyleBackColor = true;
            // 
            // txtSearchAccount
            // 
            txtSearchAccount.Location = new System.Drawing.Point(224, 19);
            txtSearchAccount.Name = "txtSearchAccount";
            txtSearchAccount.Size = new System.Drawing.Size(355, 31);
            txtSearchAccount.TabIndex = 3;
            txtSearchAccount.TextChanged += textBox1_TextChanged;
            // 
            // lbSearchAcc
            // 
            lbSearchAcc.AutoSize = true;
            lbSearchAcc.Location = new System.Drawing.Point(93, 25);
            lbSearchAcc.Name = "lbSearchAcc";
            lbSearchAcc.Size = new System.Drawing.Size(64, 25);
            lbSearchAcc.TabIndex = 2;
            lbSearchAcc.Text = "Search";
            // 
            // btnDeleteDocAccount
            // 
            btnDeleteDocAccount.Location = new System.Drawing.Point(467, 124);
            btnDeleteDocAccount.Name = "btnDeleteDocAccount";
            btnDeleteDocAccount.Size = new System.Drawing.Size(112, 34);
            btnDeleteDocAccount.TabIndex = 1;
            btnDeleteDocAccount.Text = "Delete";
            btnDeleteDocAccount.UseVisualStyleBackColor = true;
            btnDeleteDocAccount.Click += btnDeleteDocAccount_Click;
            // 
            // btnUpdateDocAccount
            // 
            btnUpdateDocAccount.Location = new System.Drawing.Point(273, 124);
            btnUpdateDocAccount.Name = "btnUpdateDocAccount";
            btnUpdateDocAccount.Size = new System.Drawing.Size(112, 34);
            btnUpdateDocAccount.TabIndex = 1;
            btnUpdateDocAccount.Text = "Update";
            btnUpdateDocAccount.UseVisualStyleBackColor = true;
            btnUpdateDocAccount.Click += btnUpdateDocAccount_Click;
            // 
            // btnCreateDocAccount
            // 
            btnCreateDocAccount.Location = new System.Drawing.Point(93, 124);
            btnCreateDocAccount.Name = "btnCreateDocAccount";
            btnCreateDocAccount.Size = new System.Drawing.Size(112, 34);
            btnCreateDocAccount.TabIndex = 1;
            btnCreateDocAccount.Text = "Create";
            btnCreateDocAccount.UseVisualStyleBackColor = true;
            btnCreateDocAccount.Click += btnCreate_Click;
            // 
            // dgvDisplayAccounts
            // 
            dgvDisplayAccounts.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgvDisplayAccounts.Location = new System.Drawing.Point(6, 207);
            dgvDisplayAccounts.Name = "dgvDisplayAccounts";
            dgvDisplayAccounts.RowHeadersWidth = 62;
            dgvDisplayAccounts.RowTemplate.Height = 33;
            dgvDisplayAccounts.Size = new System.Drawing.Size(855, 225);
            dgvDisplayAccounts.TabIndex = 0;
            dgvDisplayAccounts.RowHeaderMouseClick += dgvDisplayAccounts_RowHeaderMouseClick;
            // 
            // tpProfile
            // 
            tpProfile.Controls.Add(lbDisplayPFMode);
            tpProfile.Controls.Add(rbPatientPF);
            tpProfile.Controls.Add(rbDoctorPF);
            tpProfile.Controls.Add(btnDeletePF);
            tpProfile.Controls.Add(btnUpdatePF);
            tpProfile.Controls.Add(btnCreatePF);
            tpProfile.Controls.Add(txtSearchPF);
            tpProfile.Controls.Add(lbSearchPF);
            tpProfile.Controls.Add(dgvDisplayProfiles);
            tpProfile.Location = new System.Drawing.Point(4, 34);
            tpProfile.Name = "tpProfile";
            tpProfile.Padding = new System.Windows.Forms.Padding(3);
            tpProfile.Size = new System.Drawing.Size(870, 443);
            tpProfile.TabIndex = 1;
            tpProfile.Text = "Profile";
            tpProfile.UseVisualStyleBackColor = true;
            // 
            // lbDisplayPFMode
            // 
            lbDisplayPFMode.AutoSize = true;
            lbDisplayPFMode.Location = new System.Drawing.Point(95, 83);
            lbDisplayPFMode.Name = "lbDisplayPFMode";
            lbDisplayPFMode.Size = new System.Drawing.Size(120, 25);
            lbDisplayPFMode.TabIndex = 5;
            lbDisplayPFMode.Text = "DisplayProfile";
            // 
            // rbPatientPF
            // 
            rbPatientPF.AutoSize = true;
            rbPatientPF.Location = new System.Drawing.Point(344, 81);
            rbPatientPF.Name = "rbPatientPF";
            rbPatientPF.Size = new System.Drawing.Size(98, 29);
            rbPatientPF.TabIndex = 4;
            rbPatientPF.TabStop = true;
            rbPatientPF.Text = "Patients";
            rbPatientPF.UseVisualStyleBackColor = true;
            rbPatientPF.CheckedChanged += rbPatientPF_CheckedChanged;
            // 
            // rbDoctorPF
            // 
            rbDoctorPF.AutoSize = true;
            rbDoctorPF.Location = new System.Drawing.Point(225, 81);
            rbDoctorPF.Name = "rbDoctorPF";
            rbDoctorPF.Size = new System.Drawing.Size(100, 29);
            rbDoctorPF.TabIndex = 4;
            rbDoctorPF.TabStop = true;
            rbDoctorPF.Text = "Doctors";
            rbDoctorPF.UseVisualStyleBackColor = true;
            rbDoctorPF.CheckedChanged += rbDoctorPF_CheckedChanged;
            // 
            // btnDeletePF
            // 
            btnDeletePF.Location = new System.Drawing.Point(401, 160);
            btnDeletePF.Name = "btnDeletePF";
            btnDeletePF.Size = new System.Drawing.Size(112, 34);
            btnDeletePF.TabIndex = 3;
            btnDeletePF.Text = "Delete";
            btnDeletePF.UseVisualStyleBackColor = true;
            btnDeletePF.Click += btnDeletePF_Click;
            // 
            // btnUpdatePF
            // 
            btnUpdatePF.Location = new System.Drawing.Point(243, 160);
            btnUpdatePF.Name = "btnUpdatePF";
            btnUpdatePF.Size = new System.Drawing.Size(112, 34);
            btnUpdatePF.TabIndex = 3;
            btnUpdatePF.Text = "Update";
            btnUpdatePF.UseVisualStyleBackColor = true;
            btnUpdatePF.Click += btnUpdatePF_Click;
            // 
            // btnCreatePF
            // 
            btnCreatePF.Location = new System.Drawing.Point(95, 160);
            btnCreatePF.Name = "btnCreatePF";
            btnCreatePF.Size = new System.Drawing.Size(112, 34);
            btnCreatePF.TabIndex = 3;
            btnCreatePF.Text = "Create";
            btnCreatePF.UseVisualStyleBackColor = true;
            btnCreatePF.Click += btnCreatePF_Click;
            // 
            // txtSearchPF
            // 
            txtSearchPF.Location = new System.Drawing.Point(179, 22);
            txtSearchPF.Name = "txtSearchPF";
            txtSearchPF.Size = new System.Drawing.Size(334, 31);
            txtSearchPF.TabIndex = 2;
            txtSearchPF.TextChanged += txtSearchPF_TextChanged;
            // 
            // lbSearchPF
            // 
            lbSearchPF.AutoSize = true;
            lbSearchPF.Location = new System.Drawing.Point(95, 25);
            lbSearchPF.Name = "lbSearchPF";
            lbSearchPF.Size = new System.Drawing.Size(64, 25);
            lbSearchPF.TabIndex = 1;
            lbSearchPF.Text = "Search";
            // 
            // dgvDisplayProfiles
            // 
            dgvDisplayProfiles.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgvDisplayProfiles.Location = new System.Drawing.Point(0, 215);
            dgvDisplayProfiles.Name = "dgvDisplayProfiles";
            dgvDisplayProfiles.RowHeadersWidth = 62;
            dgvDisplayProfiles.RowTemplate.Height = 33;
            dgvDisplayProfiles.Size = new System.Drawing.Size(870, 225);
            dgvDisplayProfiles.TabIndex = 0;
            dgvDisplayProfiles.RowHeaderMouseClick += dgvDisplayProfiles_RowHeaderMouseClick;
            // 
            // tpAppointment
            // 
            tpAppointment.Controls.Add(dtpAppointmentDate);
            tpAppointment.Controls.Add(btnDeleteAppointment);
            tpAppointment.Controls.Add(btnEditAppointment);
            tpAppointment.Controls.Add(btnCreateAppointment);
            tpAppointment.Controls.Add(txtSearchAppointmentByID);
            tpAppointment.Controls.Add(cbStatus);
            tpAppointment.Controls.Add(cbSelectDoctor);
            tpAppointment.Controls.Add(Filter);
            tpAppointment.Controls.Add(label5);
            tpAppointment.Controls.Add(label4);
            tpAppointment.Controls.Add(label3);
            tpAppointment.Controls.Add(label2);
            tpAppointment.Controls.Add(dgvDisplayAppointments);
            tpAppointment.Location = new System.Drawing.Point(4, 34);
            tpAppointment.Name = "tpAppointment";
            tpAppointment.Size = new System.Drawing.Size(870, 443);
            tpAppointment.TabIndex = 2;
            tpAppointment.Text = "Appointment";
            tpAppointment.UseVisualStyleBackColor = true;
            // 
            // dtpAppointmentDate
            // 
            dtpAppointmentDate.CustomFormat = "MM/dd/yyyy - hh:mm tt";
            dtpAppointmentDate.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            dtpAppointmentDate.Location = new System.Drawing.Point(142, 6);
            dtpAppointmentDate.MinDate = new System.DateTime(2023, 4, 25, 0, 0, 0, 0);
            dtpAppointmentDate.Name = "dtpAppointmentDate";
            dtpAppointmentDate.Size = new System.Drawing.Size(300, 31);
            dtpAppointmentDate.TabIndex = 5;
            // 
            // btnDeleteAppointment
            // 
            btnDeleteAppointment.Location = new System.Drawing.Point(755, 170);
            btnDeleteAppointment.Name = "btnDeleteAppointment";
            btnDeleteAppointment.Size = new System.Drawing.Size(112, 34);
            btnDeleteAppointment.TabIndex = 4;
            btnDeleteAppointment.Text = "Delete";
            btnDeleteAppointment.UseVisualStyleBackColor = true;
            btnDeleteAppointment.Click += btnDeleteAppointment_Click;
            // 
            // btnEditAppointment
            // 
            btnEditAppointment.Location = new System.Drawing.Point(755, 130);
            btnEditAppointment.Name = "btnEditAppointment";
            btnEditAppointment.Size = new System.Drawing.Size(112, 34);
            btnEditAppointment.TabIndex = 4;
            btnEditAppointment.Text = "Edit";
            btnEditAppointment.UseVisualStyleBackColor = true;
            btnEditAppointment.Click += btnEditAppointment_Click;
            // 
            // btnCreateAppointment
            // 
            btnCreateAppointment.Location = new System.Drawing.Point(755, 90);
            btnCreateAppointment.Name = "btnCreateAppointment";
            btnCreateAppointment.Size = new System.Drawing.Size(112, 34);
            btnCreateAppointment.TabIndex = 4;
            btnCreateAppointment.Text = "Create";
            btnCreateAppointment.UseVisualStyleBackColor = true;
            btnCreateAppointment.Click += btnCreateAppointment_Click;
            // 
            // txtSearchAppointmentByID
            // 
            txtSearchAppointmentByID.Location = new System.Drawing.Point(667, 3);
            txtSearchAppointmentByID.Name = "txtSearchAppointmentByID";
            txtSearchAppointmentByID.Size = new System.Drawing.Size(200, 31);
            txtSearchAppointmentByID.TabIndex = 3;
            // 
            // cbStatus
            // 
            cbStatus.FormattingEnabled = true;
            cbStatus.Items.AddRange(new object[] { "Not Yet", "Finished" });
            cbStatus.Location = new System.Drawing.Point(142, 122);
            cbStatus.Name = "cbStatus";
            cbStatus.Size = new System.Drawing.Size(200, 33);
            cbStatus.TabIndex = 2;
            // 
            // cbSelectDoctor
            // 
            cbSelectDoctor.FormattingEnabled = true;
            cbSelectDoctor.Location = new System.Drawing.Point(142, 67);
            cbSelectDoctor.Name = "cbSelectDoctor";
            cbSelectDoctor.Size = new System.Drawing.Size(200, 33);
            cbSelectDoctor.TabIndex = 2;
            // 
            // Filter
            // 
            Filter.AutoSize = true;
            Filter.Location = new System.Drawing.Point(544, 48);
            Filter.Name = "Filter";
            Filter.Size = new System.Drawing.Size(117, 25);
            Filter.TabIndex = 1;
            Filter.Text = "FilterByStatus";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new System.Drawing.Point(3, 130);
            label5.Name = "label5";
            label5.Size = new System.Drawing.Size(90, 25);
            label5.TabIndex = 1;
            label5.Text = "Set Status";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new System.Drawing.Point(4, 70);
            label4.Name = "label4";
            label4.Size = new System.Drawing.Size(132, 25);
            label4.TabIndex = 1;
            label4.Text = "Select a Doctor";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new System.Drawing.Point(4, 12);
            label3.Name = "label3";
            label3.Size = new System.Drawing.Size(114, 25);
            label3.TabIndex = 1;
            label3.Text = "Select a Date";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new System.Drawing.Point(597, 6);
            label2.Name = "label2";
            label2.Size = new System.Drawing.Size(64, 25);
            label2.TabIndex = 1;
            label2.Text = "Search";
            // 
            // dgvDisplayAppointments
            // 
            dgvDisplayAppointments.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgvDisplayAppointments.Location = new System.Drawing.Point(0, 210);
            dgvDisplayAppointments.Name = "dgvDisplayAppointments";
            dgvDisplayAppointments.RowHeadersWidth = 62;
            dgvDisplayAppointments.RowTemplate.Height = 33;
            dgvDisplayAppointments.Size = new System.Drawing.Size(867, 230);
            dgvDisplayAppointments.TabIndex = 0;
            dgvDisplayAppointments.RowHeaderMouseClick += dgvDisplayAppointments_RowHeaderMouseClick;
            // 
            // tpHospitalBill
            // 
            tpHospitalBill.Controls.Add(dgvDisplayBillDetail);
            tpHospitalBill.Controls.Add(dgvDisplayBill);
            tpHospitalBill.Location = new System.Drawing.Point(4, 34);
            tpHospitalBill.Name = "tpHospitalBill";
            tpHospitalBill.Size = new System.Drawing.Size(870, 443);
            tpHospitalBill.TabIndex = 4;
            tpHospitalBill.Text = "HospitalBill";
            tpHospitalBill.UseVisualStyleBackColor = true;
            // 
            // dgvDisplayBillDetail
            // 
            dgvDisplayBillDetail.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgvDisplayBillDetail.Location = new System.Drawing.Point(-4, 219);
            dgvDisplayBillDetail.Name = "dgvDisplayBillDetail";
            dgvDisplayBillDetail.RowHeadersWidth = 62;
            dgvDisplayBillDetail.RowTemplate.Height = 33;
            dgvDisplayBillDetail.Size = new System.Drawing.Size(874, 228);
            dgvDisplayBillDetail.TabIndex = 0;
            // 
            // dgvDisplayBill
            // 
            dgvDisplayBill.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgvDisplayBill.Location = new System.Drawing.Point(-7, 0);
            dgvDisplayBill.Name = "dgvDisplayBill";
            dgvDisplayBill.RowHeadersWidth = 62;
            dgvDisplayBill.RowTemplate.Height = 33;
            dgvDisplayBill.Size = new System.Drawing.Size(874, 228);
            dgvDisplayBill.TabIndex = 0;
            dgvDisplayBill.RowHeaderMouseClick += dgvDisplayBill_RowHeaderMouseClick;
            // 
            // tpMedicine
            // 
            tpMedicine.Location = new System.Drawing.Point(4, 34);
            tpMedicine.Name = "tpMedicine";
            tpMedicine.Size = new System.Drawing.Size(870, 443);
            tpMedicine.TabIndex = 3;
            tpMedicine.Text = "Medicine";
            tpMedicine.UseVisualStyleBackColor = true;
            // 
            // frmMain
            // 
            AutoScaleDimensions = new System.Drawing.SizeF(10F, 25F);
            AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            ClientSize = new System.Drawing.Size(879, 479);
            Controls.Add(tcMain);
            Name = "frmMain";
            Text = "frmMain";
            Load += frmMain_Load;
            tcMain.ResumeLayout(false);
            tpAccount.ResumeLayout(false);
            tpAccount.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)dgvDisplayAccounts).EndInit();
            tpProfile.ResumeLayout(false);
            tpProfile.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)dgvDisplayProfiles).EndInit();
            tpAppointment.ResumeLayout(false);
            tpAppointment.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)dgvDisplayAppointments).EndInit();
            tpHospitalBill.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)dgvDisplayBillDetail).EndInit();
            ((System.ComponentModel.ISupportInitialize)dgvDisplayBill).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private System.Windows.Forms.TabControl tcMain;
        private System.Windows.Forms.TabPage tpAccount;
        private System.Windows.Forms.TabPage tpProfile;
        private System.Windows.Forms.TabPage tpAppointment;
        private System.Windows.Forms.TabPage tpMedicine;
        private System.Windows.Forms.DataGridView dgvDisplayAccounts;
        private System.Windows.Forms.TextBox txtSearchAccount;
        private System.Windows.Forms.Label lbSearchAcc;
        private System.Windows.Forms.Button btnDeleteDocAccount;
        private System.Windows.Forms.Button btnUpdateDocAccount;
        private System.Windows.Forms.Button btnCreateDocAccount;
        private System.Windows.Forms.DataGridView dgvDisplayProfiles;
        private System.Windows.Forms.Button btnDeletePF;
        private System.Windows.Forms.Button btnUpdatePF;
        private System.Windows.Forms.Button btnCreatePF;
        private System.Windows.Forms.TextBox txtSearchPF;
        private System.Windows.Forms.Label lbSearchPF;
        private System.Windows.Forms.RadioButton rbPatientPF;
        private System.Windows.Forms.RadioButton rbDoctorPF;
        private System.Windows.Forms.Button btnDeleteAppointment;
        private System.Windows.Forms.Button btnEditAppointment;
        private System.Windows.Forms.Button btnCreateAppointment;
        private System.Windows.Forms.TextBox txtSearchAppointmentByID;
        private System.Windows.Forms.ComboBox cbSelectDoctor;
        private System.Windows.Forms.Label Filter;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.DataGridView dgvDisplayAppointments;
        private System.Windows.Forms.DateTimePicker dtpAppointmentDate;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.ComboBox cbStatus;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TabPage tpHospitalBill;
        private System.Windows.Forms.DataGridView dgvDisplayBill;
        private System.Windows.Forms.DataGridView dgvDisplayBillDetail;
        private System.Windows.Forms.Label lbDisplayPFMode;
    }
}