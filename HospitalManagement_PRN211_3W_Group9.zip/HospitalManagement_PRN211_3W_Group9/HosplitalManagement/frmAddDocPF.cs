﻿using BusinessObjects;
using Repositories;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HosplitalManagement
{
    public partial class frmAddDocPF : Form
    {
        AccountRepository accRepo;
        DoctorRepository docRepo;
        private Doctor doctor1;
        private int role;
        public frmAddDocPF(Doctor doc, int r)
        {
            InitializeComponent();
            doctor1 = doc;
            role = r;
            accRepo = new AccountRepository();
            docRepo = new DoctorRepository();
            if (r == 1)
            {
                lbAvailableAccount.Enabled = false; cbAccountList.Enabled = false;
                lbAvailableAccount.Visible = false; cbAccountList.Visible = false;
                txtName.Text = doc.DoctorName;
                txtSpec.Text = doc.DoctorSpecialization;
            }
        }

        private Doctor GetDoctor()
        {
            Doctor doctor = new Doctor
            {
                DoctorName = txtName.Text,
                DoctorSpecialization = txtSpec.Text,
                AccountId = Int16.Parse(cbAccountList.Text),
            };
            return doctor;
        }
        private void LoadAccountComboBox()
        {
            var accounts = accRepo.GetAll();
            var doctors = docRepo.GetAll();
            List<int> accID = new List<int>();
            foreach (var account in accounts)
            {
                if (!accID.Contains(account.AccountId) && account.Role == 1)
                {
                    accID.Add(account.AccountId);
                }
            }
            List<int> docAccID = new List<int>();
            foreach (var doc in doctors)
            {
                if (!docAccID.Contains(doc.AccountId))
                {
                    docAccID.Add(doc.AccountId);
                }
            }
            var result = accID.Except(docAccID);
            foreach (var re in result)
            {
                if (!cbAccountList.Items.Contains(re))
                {
                    cbAccountList.Items.Add(re);
                }
            }
        }

        private void btnCreate_Click(object sender, EventArgs e)
        {
            if (role == 1)
            {
                if (txtName.Text == string.Empty || txtSpec.Text == string.Empty)
                {
                    MessageBox.Show("Please do not leave any field empty");
                }
                else
                {
                    try
                    {
                        doctor1.DoctorName = txtName.Text;
                        doctor1.DoctorSpecialization = txtSpec.Text;
                        docRepo.Update(doctor1);
                        MessageBox.Show("Doctor's profile updated successfully");
                    }
                    catch { MessageBox.Show("Doctor profile updates failed"); }
                }
            }
            else if (role == 0)
            {
                if (txtName.Text == string.Empty || txtSpec.Text == string.Empty || cbAccountList.Text == string.Empty)
                {
                    MessageBox.Show("Please do not leave any field empty");
                }
                else
                {
                    Doctor doctor = GetDoctor();
                    DoctorRepository repository = new DoctorRepository();
                    try
                    {
                        repository.Insert(doctor);
                        MessageBox.Show("Doctor Profile created successfully");
                    }
                    catch { MessageBox.Show("Insert failed"); }
                }
            }

        }

        private void frmAddDocPF_Load(object sender, EventArgs e)
        {
            LoadAccountComboBox();
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
