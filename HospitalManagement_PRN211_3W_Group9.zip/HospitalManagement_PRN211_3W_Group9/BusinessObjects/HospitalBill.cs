﻿using System;
using System.Collections.Generic;

#nullable disable

namespace BusinessObjects
{
    public partial class HospitalBill
    {
        public HospitalBill()
        {
            PrescriptionDetails = new HashSet<PrescriptionDetail>();
        }

        public short BillId { get; set; }
        public DateTime BillDate { get; set; }
        public double TotalPrice { get; set; }
        public short AppointmentId { get; set; }

        public virtual ICollection<PrescriptionDetail> PrescriptionDetails { get; set; }
    }
}
