﻿using System;
using System.Collections.Generic;

#nullable disable

namespace BusinessObjects
{
    public partial class MedicineStorage
    {
        public MedicineStorage()
        {
            PrescriptionDetails = new HashSet<PrescriptionDetail>();
        }

        public short MedicineId { get; set; }
        public string MedicineName { get; set; }
        public long MedicinePrice { get; set; }
        public long MedicineAmount { get; set; }

        public virtual ICollection<PrescriptionDetail> PrescriptionDetails { get; set; }
    }
}
